package com.lvistech.appu

import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.SaveMode

object DataLoader {

  case class RFData(name: String, ac: String)
  case class SimData(name: String, matrix: Array[Array[Double]])
  case class TrdData(trd_id: String , cpty_id : String, netting : String , collateral: String , rfs : List[String])

  private def genRadoms(rows: Int, cols: Int): Array[Array[Double]] = {

    val rand = scala.util.Random

    Array.fill(rows, cols) { rand.nextDouble() }
  }

  private def getRFs(count: Int, ac: String): List[RFData] = {

    var rfs = ArrayBuffer.empty[RFData]

    for (i <- 1 to count) {
      rfs += RFData("rf_" + ac + "_" + i, ac);
    }

    rfs.toList

  }

  def getTrds(num: Int, rfs: List[String], maxRFCount : Int=2500): TrdData = {

    val rand = scala.util.Random
    
    val no_riskfactors = 1 + rand.nextInt(maxRFCount-1)
    
    TrdData("trd_" + num, "cpty" , "netting" , "collateral" , scala.util.Random.shuffle(rfs).take(no_riskfactors))
    
    

  }
  
  
  private def populateRFs(spark: SparkSession, outputFile: String, irCount: Int, fxCount: Int, commCount: Int, stockCount: Int): Unit = {

    val irs = getRFs(irCount, "IR")
    val fxs = getRFs(fxCount, "FX")
    val comms = getRFs(commCount, "Comm")
    val stocks = getRFs(stockCount, "Stock")

    val rfs = irs ++ fxs ++ comms ++ stocks

    import spark.implicits._
    val rfs_df = rfs.toDF()

    // populate RFs (Simulation data)

    val simdata = rfs_df.map(x => SimData(x.getString(0), genRadoms(5000, 100)))

    //val one_element = simdata.head

    //print(one_element.matrix.map(_.mkString(";")).mkString("\n"))

    // save as parquet
    simdata.write.mode(SaveMode.Overwrite).parquet(outputFile)
  }

  private def populateTrades(spark: SparkSession, outputFile: String, tradeCount :Int = 500000, irCount: Int =100000, fxCount: Int=2000, commCount: Int =100000 , stockCount: Int =100000, maxRFCount : Int=2500): Unit = {

    import spark.implicits._
    import org.apache.spark.sql.catalyst.expressions._

    val irs = getRFs(irCount, "IR")
    val fxs = getRFs(fxCount, "FX")
    val comms = getRFs(commCount, "Comm")
    val stocks = getRFs(stockCount, "Stock")

    val rfs = irs ++ fxs ++ comms ++ stocks

    val rfnames = rfs.map(x => x.name)

    val trd_number = 1 to tradeCount

    val trd_df = trd_number.toDF()

    import spark.implicits._

    val trds = trd_df.map(x => getTrds(x.getInt(0), rfnames))

    trds.write.mode(SaveMode.Overwrite).parquet(outputFile)

  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.
      appName("Spark Datagenerator")
      .getOrCreate()

    val rfPath = "/tmp/rfs/simdata/rfs1.parquet"
    val irCount = 10000
    val fxCount = 200
    val commCount = 10000
    val stockCount = 10000

    populateRFs(spark, rfPath, irCount, fxCount, commCount, stockCount)

    
    val tradesPath = "/tmp/rfs/simdata/trds1.parquet"
    
    
    populateTrades(spark,tradesPath)

  }

}