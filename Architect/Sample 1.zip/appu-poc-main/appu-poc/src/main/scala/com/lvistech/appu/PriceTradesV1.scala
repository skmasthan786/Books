package com.lvistech.appu

import org.apache.spark.sql.SparkSession
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.SaveMode



object PriceTradesV1 {
   def priceTrade(trd: org.apache.spark.sql.Row) = {

    val list = trd.getList(1)
    val trd_id = trd.getString(0)
    val rand = scala.util.Random

    //.matrix.map(_.mkString(";")).mkString("\n")
    //Thread.sleep(1000)

    (trd_id, list.size, rand.nextDouble())
  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.
      appName("Trade Valuation")
      .getOrCreate()

    // create trades
    import spark.implicits._
    
    
    
      

    import org.apache.spark.sql.functions._
    val trd_df = spark.read.parquet("/tmp/rfs/simdata/trds1.parquet")

    val flat_trd = trd_df.withColumn("rf", explode($"rfs")).drop("rfs")

    val sim_df = spark.read.parquet("/tmp/rfs/simdata/rfs1.parquet")

    val result_df = flat_trd.join(sim_df, flat_trd("rf") === sim_df("name"), "inner").select("trd_id", "rf", "matrix")

    //result_df.cache
    //sim_df.cache

    val agg_df = result_df.groupBy("trd_id").agg(collect_list(struct($"rf", $"matrix")).as("rfs"))
    
    .map(x => priceTrade(x))

    agg_df.write.mode(SaveMode.Overwrite).parquet("/tmp/rfs/simdata/pricedtrades.parquet")
  }
}