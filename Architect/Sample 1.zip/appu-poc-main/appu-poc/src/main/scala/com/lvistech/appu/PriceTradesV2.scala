package com.lvistech.appu

import org.apache.spark.sql.SparkSession
import org.apache.commons.math.linear.Array2DRowRealMatrix
import scala.collection.mutable.ArrayBuffer
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.functions.col
import scala.collection.JavaConverters._
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions.{ collect_list, struct }
import scala.collection.JavaConverters._

object PriceTradesV2 {
  case class MyTestCaseClass(bucket_id: String, trades: List[String], rfs: List[String])

  def priceTradeBucket(row: org.apache.spark.sql.Row) = {

    val trade_list = row.getList[String](1).asScala
    val rf_list = row.getList(2)
    val trd_id = row.getString(0)
    val rand = scala.util.Random
    var ttt = ArrayBuffer.empty[(String, Double, Int)]

    for (item <- trade_list) {
      val v = (item.toString, rand.nextDouble(), rf_list.size)
      ttt += v
    }

    //trade_list.size()

    // //.matrix.map(_.mkString(";")).mkString("\n")
    // //Thread.sleep(1000)

    ttt.toList

  }

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder.
      appName("Spark Load Test")
      .getOrCreate()

    val sim_df = spark.read.parquet("/tmp/rfs/simdata/file1.parquet")

    val tradesOrg = spark.read.parquet("/tmp/rfs/simdata/trds1.parquet")

    val trades = tradesOrg.withColumn("rfs", concat_ws("|", col("rfs")))

    val partitioned_trades = trades.repartition(200)

    val trd_df = partitioned_trades.rdd.mapPartitionsWithIndex(
      (index, it) => {

        var trds = ArrayBuffer.empty[String]
        var rfs = ArrayBuffer.empty[String]

        for (item <- it) {
          trds += item.getString(0)
          val list = item.getString(4).split("\\|").map(_.trim).toList
          rfs ++= list
        }
        Iterator(MyTestCaseClass(index.toString, trds.toList, rfs.toSet.toList))
      })

    import spark.implicits._
    
    
    


    val flat_trd = trd_df.toDF.withColumn("rf", explode($"rfs")).drop("rfs")


    val result_df = flat_trd.join(sim_df, flat_trd("rf") === sim_df("name"), "inner").select("bucket_id", "trades", "rf", "matrix")
    


     val agg_df = result_df.groupBy("bucket_id").agg(collect_set(struct($"rf", $"matrix")).as("rfs"))


    val trds_tmp = result_df.select("bucket_id", "trades")

    val final_df = trds_tmp.join(agg_df, "bucket_id")


    val priced_df = final_df.map(x => priceTradeBucket(x))

    priced_df.write.mode(SaveMode.Overwrite).parquet("/tmp/rfs/simdata/pricedtrades.parquet")
  }
}